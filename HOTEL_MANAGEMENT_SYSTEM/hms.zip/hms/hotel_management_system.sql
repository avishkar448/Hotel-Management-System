-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: hotel_management_system
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `document` varchar(20) DEFAULT NULL,
  `number` varchar(20) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `gender` varchar(15) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `phone_no` varchar(20) DEFAULT NULL,
  `country` varchar(20) DEFAULT NULL,
  `room_no` varchar(20) DEFAULT NULL,
  `check_in_time` varchar(80) DEFAULT NULL,
  `deposit` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES ('Aadhar-Card','123456789123','Amol','Male','amol12@gmail.com','9035465734','India','105','Tue Apr 25 00:37:45 IST 2023','2000'),('Aadhar-Card','345654567894','Abhay Pawar','Male','abhi34@gmail.com','9067856978','India','104','Fri May 12 17:01:29 IST 2023','2000'),('Aadhar-Card','678956456767','Rakesh Sharma','Male','Rocky@gmail.com','9989986756','India','107','Fri May 12 17:03:40 IST 2023','1500'),('Aadhar-Card','765678754356','Avishkar Gawali','Male','avishkar@gmail.com','9878657654','India','106','Wed Apr 19 12:11:23 IST 2023','4000'),('Aadhar-Card','789067584657','Akshay Kale','Male','akshay378@gmail.com','9867567890','India','102','Fri May 12 17:02:27 IST 2023','3000');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `department` (
  `department` varchar(40) NOT NULL,
  `budget` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`department`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES ('Engineering and Maintenance Department','50000'),('Food and Beverange Service Department','100000'),('Food production Department','90000'),('Front Office Department','80000'),('HouseKeeping Department','50000'),('Security Department','30000');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `driver`
--

DROP TABLE IF EXISTS `driver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `driver` (
  `Name` varchar(20) DEFAULT NULL,
  `age` varchar(20) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `company` varchar(20) DEFAULT NULL,
  `Brand` varchar(20) DEFAULT NULL,
  `avalibility` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `driver`
--

LOCK TABLES `driver` WRITE;
/*!40000 ALTER TABLE `driver` DISABLE KEYS */;
INSERT INTO `driver` VALUES ('Name','34','Male','Mahindra','XUV','Available');
/*!40000 ALTER TABLE `driver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `employee_id` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `father_name` varchar(30) DEFAULT NULL,
  `date_of_birth` varchar(30) DEFAULT NULL,
  `age` varchar(10) DEFAULT NULL,
  `gender` varchar(15) DEFAULT NULL,
  `education` varchar(30) DEFAULT NULL,
  `job` varchar(15) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `adhar` varchar(15) DEFAULT NULL,
  `salary` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (NULL,'Abhay Gawali',NULL,NULL,'17','Male',NULL,'Room Service','9011463377','abhaygawali','234789436754','30000'),('23322','Harsh Pawar','Sarthak pawar','12/04/1946','32','Male','12th','Manager','8943567489','harsh@gmail.com','32','70000'),('2345','Ganesh Gaikwad','Rakesh','12/04/1980','33','Male','12th','Waiter','9034546783','ganesh23@gmail.com','33','25000'),('3243','Avishkar Gawali','Ashok Gawali','12/03/2003','21','Male','Bcs','Manager','9730328530','avishkargawali@gmail.com','865432356798','50000'),('4321','Vilas Jagtap','vikas jagtap','dd-MMM-y','27','Male','10th','Room Service','90324675843','vilas@gmail.com','987656787690','15000'),('3453','Rakesh Shinde','Akshay Shinde','23/01/2003','20','Male','B.com','Accountant','9023675467','Rakesh23@gmail.com','907865764563','40000');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login` (
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES ('avishkar','12120'),('admin','12345');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room` (
  `room_no` varchar(10) DEFAULT NULL,
  `availability` varchar(20) DEFAULT NULL,
  `Cleaning_Status` varchar(20) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `bed_type` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES ('101','Occupied','Cleaned','2500','Single Bed'),('102','Occupied','dirty','5000','Double Bed'),('103','Occupied','Cleaned','5000','Double Bed'),('104','Occupied','Cleaned','6000','Double Bed'),('105','Occupied','Cleaned','5000','Single Bed'),('106','Occupied','Cleaned','6000','Double Bed'),('107','Occupied','Cleaned','5000','Double Bed'),('108','Available','Cleaned','5000','Double Bed'),('109','Available','Cleaned','4000','Single Bed'),('110','Available','Cleaned','4500','Double Bed'),('201','Available','Cleaned','4000','Single Bed'),('202','Available','Cleaned','6000','Double Bed'),('203','Available','Cleaned','7000','Single Bed'),('204','Available','Cleaned','6000','Single Bed'),('205','Available','Cleaned','4500','Single Bed');
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-23 12:01:22
